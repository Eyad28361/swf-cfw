Version: Build 0.2.3, 09/08/2022 19:46
==========

.. image:: https://discord.com/api/guilds/1099725040506896444/embed.png
   :target: https://discord.gg/Dcgm56f89P
   :alt: Discord server invite
   
About Project:
-------------

This website was inspired by a few questions I found around on different websites of people looking for a basic website for a FiveM server, Well thats what I did over the past few weeks,
I decided to build this website which is a simple site that even basic coders can understand, I will be bringing more updates out! (Check Future Plans At Bottom for more info on my plans),

Do you have a suggestion? Let me know! 

- `Official Discord Server <https://discord.gg/Dcgm56f89P>`_

Email: CharleyJ@hamster-sys.com


Demo Link: **Coming back soon**

Please Remember!
-------------
We ask you to keep copyright for this website; Please recognise this is a GPL V3 License; Please follow them keeping it to the guidelines. Want to avoid this license please contact us at CharleyJ@hamster-sys.com

Changelog:
-------------
09/08/2022

- + Updated all pages with being able to access CSS while using .htaccess (FriendlyURL's)
- + Added Partners Page (Early Work)
- + Added Demo Link

30/07/2022:

- + Added Gallery Page.
- + Commented Code.
- + Made Main Home Page With Basic Details On, As Well As Server IP & Port Access.
- + Added Custom News For Your Community!
- + Staff Team

Fetures:
-------------
- + Fully Commented Code (WIP)
- + Gallery & Captions W/ Example Images (Check Demo Site For More)
- + Latest News Feture (No Backpanel Yet - Upcoming Feture)
- + Staff Team Page
- + Show Server IP & Port On The Main Page W/ Click To Copy Feture!

Requirements:
-------------

- + Latest Version Of PHP

Photos:
--------

Main Page:
--------

.. image:: https://github.com/Coldalliance/FiveM-Website-Template/blob/master/backend/img/GitHubImages/CharleyJ-FiveM-Template-Site-1.png
    :height: 280px
    :width:  456px

Bottom Main Page:
--------

.. image:: https://github.com/Coldalliance/FiveM-Website-Template/blob/master/backend/img/GitHubImages/CharleyJ-FiveM-Template-Site-2.png
    :height: 280px
    :width:  456px
    
Staff Page:
--------

.. image:: https://github.com/Coldalliance/FiveM-Website-Template/blob/master/backend/img/GitHubImages/CharleyJ-FiveM-Template-Site-3.png
    :height: 280px
    :width:  456px
    
Gallery Page:
--------

.. image:: https://github.com/Coldalliance/FiveM-Website-Template/blob/master/backend/img/GitHubImages/CharleyJ-FiveM-Template-Site-4.png
    :height: 280px
    :width:  456px
  
  
Links:
------

- `Documentation (COMING SOON) <https://hamsternetwork.com>`_ 
- `Official Discord Server <https://discord.gg/Dcgm56f89P>`_

Future Plans:
------

- + Backend Panel I.E Admin Panel For Images, Latest News, Much More! (Started)
- + Friendly URL's so (this.is.a.friendly.link.com/home instead of this.is.a.friendly.link.com/home.php) ✅
- + Partnership Page (Started)
- + Contact Us Page
- + Basic Applications Page
